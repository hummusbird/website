WallpaperChanger by hummusbird
Contact me @hummusbirb or hummusbird#0378

Running the EXE produces a standard json config file. This is where the timings are stored, the wallpaper fit, the prefix path to the four wallpaper files, and the filetype extention. Set the EXE to run on login, and then run every hour in task scheduler for the best experience.

Please end your wallpaper filenames with these suffixes: night sunrise day sunset

Times in the .cfg are stored in 24hr format. The program will check your system clock, and change the wallpaper when appropriate.

If you mess up your config, or your wallpaper is black, delete the .cfg and run the .EXE again. 

Wallpapers included are edits of the Surface Laptop 3 default wallpapers, by u/Cacaio_7

v1.1

Fixes an issue that occurs when the wallpaper is changed at exactly 8:00PM